package com.cg.banking.service;

import java.sql.SQLException;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransaction;
import com.cg.banking.dao.BankingDaoImpl;
import com.cg.banking.dao.BankingDao;
import com.cg.banking.exception.*;

public class BankingServiceImpl implements BankingService {

	BankingDao dao = (BankingDao) new BankingDaoImpl();
	BankingBean bank = new BankingBean();
	BankingBean bank1 = new BankingBean();

	boolean res;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String address, long accountNo, String phone, int balance)
			throws AccountAlreadyExistException, ClassNotFoundException, SQLException {

		BankingBean bean = new BankingBean();
		boolean res = false;
		res = dao.checkAccount(accountNo);

		if (res) {
			bean.setAccountNo(accountNo);
			bean.setAddress(address);
			bean.setBalance(balance);
			bean.setName(name);
			bean.setPhoneNo(phone);
			dao.InsertData(accountNo, bean);

			res = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistException();
		}
		return res;

	}

	// to show balance

	public int showBalance(long accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		try {
			res = dao.checkAccount(accountNo);
		}

		catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		int balance = 0;

		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accountNo);
			balance = bank.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accountNo, int depositAmount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			res = dao.checkAccount(accountNo);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accountNo);
		}
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bank.setBalance(bank.getBalance() + depositAmount);
			// dao.InsertData(accNo,bank);
			dao.updateData(bank);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accountNo, int withdrawAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			res = dao.checkAccount(accountNo);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accountNo);
			if (bank == null) {
				throw new AccountNotFoundException();
			}
			if (bank.getBalance() > withdrawAmount) {
				balance = bank.setBalance(bank.getBalance() - withdrawAmount);
			} else {
				throw new LowBalanceException();
			}
			// dao.InsertData(accNo, bank);
			dao.updateData(bank);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long sendersAccountNo, long recieversAccNo, int transferAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		res = dao.checkAccount(sendersAccountNo);
		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(sendersAccountNo);
			int balance = bank.getBalance();
			res = validateBalance(sendersAccountNo, transferAmount);
			if (res) {
				res = dao.checkAccount(recieversAccNo);
				if (res) {
					throw new AccountNotFoundException();
				} else {
					bank1 = dao.getAccountDetails(recieversAccNo);
					int balance1 = bank1.getBalance();
					bank.setBalance(balance - transferAmount);
					bank1.setBalance(balance1 + transferAmount);
					dao.updateData(bank);
					dao.updateData(bank1);
				}
			} else {
				throw new LowBalanceException();

			}
		}
		return true;
	}

	// to validateBalance

	public boolean validateBalance(long accountNo, int amount)
			throws LowBalanceException, AccountNotFoundException, ClassNotFoundException, SQLException

	{

		res = dao.checkAccount(accountNo);
		if (res) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accountNo);
			int balance = bank.getBalance();
			if (balance < amount) {
				throw new LowBalanceException();
			} else {
				return true;
			}
		}
	}

	// to set transactions

	@Override
	public void setTransactions(BankingTransaction trans) throws ClassNotFoundException, SQLException {

		dao.setTransactions(trans);
	}

	@Override
	public BankingTransaction getTransactions(long accountNo) throws ClassNotFoundException, SQLException {
		BankingTransaction trans = new BankingTransaction();
		trans = dao.getTransactions(accountNo);
		return trans;
	}
}
