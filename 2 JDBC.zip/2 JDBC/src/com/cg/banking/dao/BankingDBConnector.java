package com.cg.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BankingDBConnector {

	public static Connection getConnection() throws ClassNotFoundException,
			SQLException {
		String driverName = "oracle.jdbc.driver.OracleDriver";
		Class.forName(driverName);
		Connection con = DriverManager.getConnection(
				"jdbc:oracle:thin:@localhost:1521:XE", "INVENTORY1",
				"INVENTORY1");

		return con;
	}
}
