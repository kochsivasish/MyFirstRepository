package com.cg.banking.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.banking.bean.BankingTransaction;
import com.cg.banking.exception.*;
import com.cg.banking.service.BankingServiceImpl;
import com.cg.banking.service.BankingService;

public class BankingUi {
	static Scanner sc = new Scanner(System.in);
	static BankingTransaction trans = new BankingTransaction();
	static BankingTransaction trans1 = new BankingTransaction();

	public static void main(String[] args) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		// variables
		long accountNo, accountNo1;
		int withdrawAmount, depositAmount = 0, transferAmount = 0;
		int amount = 0;
		int balance = 0;
		boolean res = false;

		BankingService service = new BankingServiceImpl();
		
		System.err.println("\t\t\t\t\t\t\t*** Welcome to HDFC Bank ***");

		// To ask choice from users and perform operations
		while (true) {
			
			// to display menu
			System.out.println("\nChoose one...\n");
			System.out.println("1. Create New Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw Amount");
			System.out.println("5. Transer Fund");
			System.out.println("6. Print Transcations");
			System.out.println("7. Exit");

			int choice = sc.nextInt();
			String s = Integer.toString(choice);
						
			while (!s.matches("[0-7]{1}")) {
				System.out.println("\n\t\t\t\t\t\t\tInvalid Choice");
				System.out.println("\t\t\t\t\t\t\tPlease enter Choice again ...! (1-7)");
				choice = sc.nextInt();
			}
			
			switch (choice) {

			// to create account
			case 1:
				accountNo = (long) (Math.random() * 1000000) + 190000000;
				
				System.out.println("Enter your name :");
				String name = sc.nextLine();
				name += sc.nextLine();

				while (!name.matches("[A-Za-z\\s]+$")) {
					System.out.println("\n\t\t\t\t\t\tInvalid Format...!");
					System.out.println("Please enter your name again :");
					name = sc.next();
				}

				System.out.println("Enter your address ");
				String address = sc.next();
				address += sc.nextLine();

				while (!address.matches("[A-Za-z0-9\\s,\\.-]+$")) {
					System.out.println("\n\t\t\t\t\t\tInvalid Format...!");
					System.out.println("Please enter your address again :");
					address = sc.nextLine();
				}

				//accepting phone
				System.out.println("Enter your phone number :");
				String phoneNo = sc.next();

				//validating phone
				while (!phoneNo.matches("[6-9][0-9]{9}")) {
					if (phoneNo.length() < 10 || phoneNo.length() > 10) {
						System.out
								.println("\n\t\t\t\t\t\t\tYour phone number should be 10 digits ...!");
						System.out.println("Please enter valid phone number :");
						phoneNo = sc.next();
					}else {
						System.out
								.println("\n\t\t\t\t\t\t\tPhone number should start from 6/7/8/9 ...!");
						System.out.println("Please enter valid phone number :");
						phoneNo = sc.next();
					}
				}

				//accepting initial balance
				System.out.println("Enter the initial Balance :");
				int bal = sc.nextInt();

				//validating balance
				while (bal < 1000) {
					System.out
							.println("Initial Balance should be 1000 or more ...!");
					System.out.println("Please enter valid initial balance :");
					bal = sc.nextInt();
				}
				try {
					res = service.createAccount(name, address, accountNo, phoneNo, balance);
				} catch (AccountAlreadyExistException e) {

					System.out.println(e);
					break;
				}

				if (res == true) {
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number : " + accountNo);

					int trans_id = ((int) Math.random() * 1000 + 1000);
					trans.setAccNo(accountNo);
					trans.setType("Create");
					trans.setAmount(balance);
					trans.setTransaction_id(trans_id);

					service.setTransactions(trans);

				} else {

					System.out.println("Cannot Create Account");
				}

				break;

			// to show balance
			case 2:

				System.out.println("Enter account number");
				accountNo = sc.nextLong();

				try {
					balance = service.showBalance(accountNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit

			case 3:

				System.out.println("Enter account no");
				accountNo = sc.nextLong();

				System.out.println("Enter amount to be deposited");
				depositAmount = sc.nextInt();

				try {
					amount = service.deposit(accountNo, depositAmount);

					balance = service.showBalance(accountNo);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + depositAmount);
				System.out.println("Updated Balance : " + balance);

				int trans_id = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accountNo);
				trans.setType("Deposit");
				trans.setAmount(depositAmount);
				trans.setTransaction_id(trans_id);
				service.setTransactions(trans);

				break;

			// to withdraw

			case 4:

				System.out.println("Enter account no");
				accountNo = sc.nextLong();

				System.out.println("Enter amount to withdraw");
				withdrawAmount = sc.nextInt();

				try {
					amount = service.withdraw(accountNo, withdrawAmount);
					res = service.validateBalance(accountNo, withdrawAmount);
					balance = service.showBalance(accountNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdrawAmount);
				System.out.println("Updated Balance : " + balance);

				int trans_id1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accountNo);
				trans.setType("Withdraw");
				trans.setAmount(withdrawAmount);
				trans.setTransaction_id(trans_id1);
				service.setTransactions(trans);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter account no");
				accountNo = sc.nextLong();

				System.out.println("Enter account to which you want to transfer fund");
				accountNo1 = sc.nextLong();

				System.out.println("Enter amount to transfer");
				transferAmount = sc.nextInt();

				try {
					res = service.validateBalance(accountNo, transferAmount);
					res = service.transferfund(accountNo, accountNo1, transferAmount);

					senders_balance = service.showBalance(accountNo);
					recievers_balance = service.showBalance(accountNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Updated balance for Account " + accountNo + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accountNo1 + " : " + recievers_balance);

				int trans_id_1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accountNo);
				trans.setType("Transfer");
				trans.setAmount(transferAmount);
				trans.setTransaction_id(trans_id_1);
				service.setTransactions(trans);

				int trans_id_2 = ((int) Math.random() * 1000 + 1000);
				trans1.setAccNo(accountNo1);
				trans1.setType("Transfer");
				trans1.setAmount(transferAmount);
				trans1.setTransaction_id(trans_id_2);
				service.setTransactions(trans1);

				break;

			// to show transactions
			case 6:

				System.out.println("Enter account number");
				accountNo = sc.nextLong();
				trans = service.getTransactions(accountNo);
				if (trans == null) {
					throw new AccountNotFoundException();
				} else {
					System.out.println("--------Transactions----------");
					System.out.println("Transaction type : " + trans.getType());
					System.out.println("Transaction Id : " + trans.getTransaction_id());
					System.out.println("Transaction Account : " + trans.getAccNo());
					System.out.println("Transaction Amount : " + trans.getAmount());
				}

				// to exit
			case 7:
				System.err
				.println("\n\t\t\t\t\t\t\t  ***Exit Successful***\n\t\t\t\t\t\t\t***Thanks for visiting***");
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				break;

			}
		}

	}
}
