package com.cg.banking.bean;

public class BankingBean {

	private String name;
	private long accountNo;
	private String address;
	private String phoneNo;
	private int balance;

	public BankingBean(String name, int accountNo, String address, String phoneNo, int balance) {
		super();
	}

	public BankingBean() {
		// TODO Auto-generated constructor stub
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public long setAccountNo(long accountNo) {
		return this.accountNo = accountNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "AccountDetails name =" + name + "\n accNo =" + accountNo + "\n add =" + address
				+ "\n phone =" + phoneNo + "\nbalance =" + balance;
	}
}