package com.cg.banking.exception;

public class AccountAlreadyExistException extends Exception {

	public AccountAlreadyExistException() {

	}

	@Override
	public String toString() {
		return "Account Already Exists";
	}

}
