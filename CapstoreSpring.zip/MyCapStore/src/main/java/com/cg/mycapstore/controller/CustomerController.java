package com.cg.mycapstore.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mycapstore.bean.Customer;
import com.cg.mycapstore.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@Transactional
public class CustomerController {

	@Autowired
	CustomerService custService;
	
	@RequestMapping("/login/customer/{email}/{password}")
	public Customer customerLogin(@PathVariable String email,@PathVariable String password) {
		return custService.customerLogin(email, password);
	}
	
	@PutMapping("/updateProfile/{email}")
	public void updateCustomer(@PathVariable String email, @RequestBody Customer updatedCustomer) {
		custService.updateCustomer(email, updatedCustomer);
	}
}
