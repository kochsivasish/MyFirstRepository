package com.cg.mycapstore.service;

import org.springframework.stereotype.Service;

import com.cg.mycapstore.bean.Customer;


public interface CustomerService {

	public Customer customerLogin(String email, String password);
	public void updateCustomer(String email, Customer updatedCustomer);
}
