import { Injectable } from '@angular/core';
import { Customer } from './Customer';
import { Observable } from '../../node_modules/rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  customer: Customer;
  constructor(private http: HttpClient) { }

  public loginCustomer(emailId: String, password: String): Observable<Customer> {

    return this.http.get<Customer>('http://localhost:4567/login/customer/' + emailId + '/' + password)
  }
  public updateProfile(customer: Customer): Observable<Customer>{
    return this.http.put<Customer>('http://localhost:4567/updateProfile/'+ this.customer.email,customer);
  }

  setCustomer(customer){
    this.customer = customer;
  }
  getCustomer(){
    return this.customer;
  }
}
