export class Customer{
    custId: number;
	firstName: string ;
	lastName: string ;
	email: string ;
	phone: string ;
	address: string ;
}