import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../Customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service: CustomerService, public router: Router) { }

  ngOnInit() {
  }

  loginCustomer(email: string,password: string) {
    this.service.loginCustomer(email,password).subscribe((customer) => {
    
      console.log(customer);
      this.service.setCustomer(customer);    
      this.router.navigate(['/dashboard']); 
    })
  }
  
}