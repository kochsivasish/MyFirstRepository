import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  customer: Customer;
  constructor(private service: CustomerService,private router: Router) { }

  ngOnInit() {
    this.customer = this.service.getCustomer();
  }

  saveAttributes(firstName: string,lastName: string,address: string,phone: string){
    if(firstName != '')
    this.customer.firstName = firstName
    if(lastName != '')
    this.customer.lastName = lastName
    if(address != '')
    this.customer.address = address
    if(phone != '')
    this.customer.phone = phone;
    this.service.updateProfile(this.customer).subscribe(data=>{
      alert("Profile updated")
    });
    this.router.navigate(['/dashboard']);
  }
}
