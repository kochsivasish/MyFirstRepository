package com.cg.banking.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.banking.bean.BankingTransaction;
import com.cg.banking.exception.*;
import com.cg.banking.service.BankingServiceImpl;
import com.cg.banking.service.BankingService;

public class BankingUi {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		// variables
		long accountNo, accountNo1;
		int amount = 0;
		int balance = 0;
		BankingService service = new BankingServiceImpl();
		
		System.err.println("\t\t\t\t\t\t\t*** Welcome to HDFC Bank ***");

		// To ask choice from users and perform operations
		while (true) {
			
			// to display menu
			System.out.println("\nChoose one...\n");
			System.out.println("1. Create New Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw Amount");
			System.out.println("5. Transer Fund");
			System.out.println("6. Print Transcations");
			System.out.println("7. Exit");

			int choice = sc.nextInt();
			String s = Integer.toString(choice);
						
			while (!s.matches("[0-7]{1}")) {
				System.out.println("\n\t\t\t\t\t\t\tInvalid Choice");
				System.out.println("\t\t\t\t\t\t\tPlease enter Choice again ...! (1-7)");
				choice = sc.nextInt();
			}
			
			switch (choice) {

			// to create account
			case 1:
				accountNo = (long) (Math.random() * 1000000) + 190000000;
				
				System.out.println("Enter your name :");
				String name = sc.nextLine();
				name += sc.nextLine();

				while (!name.matches("[A-Za-z\\s]+$")) {
					System.out.println("\n\t\t\t\t\t\tInvalid Format...!");
					System.out.println("Please enter your name again :");
					name = sc.next();
				}

				System.out.println("Enter your address ");
				String address = sc.next();
				address += sc.nextLine();

				while (!address.matches("[A-Za-z0-9\\s,\\.-]+$")) {
					System.out.println("\n\t\t\t\t\t\tInvalid Format...!");
					System.out.println("Please enter your address again :");
					address = sc.nextLine();
				}

				//accepting phone
				System.out.println("Enter your phone number :");
				String phoneNo = sc.next();

				//validating phone
				while (!phoneNo.matches("[6-9][0-9]{9}")) {
					if (phoneNo.length() < 10 || phoneNo.length() > 10) {
						System.out
								.println("\n\t\t\t\t\t\t\tYour phone number should be 10 digits ...!");
						System.out.println("Please enter valid phone number :");
						phoneNo = sc.next();
					}else {
						System.out
								.println("\n\t\t\t\t\t\t\tPhone number should start from 6/7/8/9 ...!");
						System.out.println("Please enter valid phone number :");
						phoneNo = sc.next();
					}
				}

				//accepting initial balance
				System.out.println("Enter the initial Balance :");
				int bal = sc.nextInt();

				//validating balance
				while (bal < 1000) {
					System.out
							.println("Initial Balance should be 1000 or more ...!");
					System.out.println("Please enter valid initial balance :");
					bal = sc.nextInt();
				}
				try {
					service.createAccount(name, address, accountNo, phoneNo, balance);
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number : " + accountNo);
				} catch (AccountAlreadyExistException e) {
					System.out.println("Cannot create account\n"+e);
					break;
				}

				break;

			// to show balance
			case 2:

				System.out.println("Enter account number");
				accountNo = sc.nextLong();
				try {
					balance = service.showBalance(accountNo);
					System.out.println("Balance :" + balance);
				} catch (AccountNotFoundException|ClassNotFoundException|SQLException e) {
					System.out.println(e);
					break;
				}
				break;

			// to deposit

			case 3:
				System.out.println("Enter account no");
				accountNo = sc.nextLong();
				System.out.println("Enter amount to be deposited");
				amount = sc.nextInt();
				try {
					balance = service.deposit(accountNo, amount);
					System.out.println("Amount Deposited : " + amount);
					System.out.println("Updated Balance : " + balance);
				}
				catch (AccountNotFoundException|ClassNotFoundException|SQLException e) {
					System.out.println(e);
					break;
				}
				break;

			// to withdraw

			case 4:

				System.out.println("Enter account no");
				accountNo = sc.nextLong();
				System.out.println("Enter amount to withdraw");
				amount = sc.nextInt();
				try {
					balance = service.withdraw(accountNo, amount);
					System.out.println("Amount Withdrawn : " + amount);
					System.out.println("Updated Balance : " + balance);

				} catch (AccountNotFoundException|LowBalanceException|ClassNotFoundException|SQLException e) {
					System.out.println(e);
					break;
				} 
				break;

			// to transfer fund

			case 5:
				int ubal[] = new int[2];
				System.out.println("Enter senders account number");
				accountNo = sc.nextLong();
				System.out.println("Enter receivers account number");
				accountNo1 = sc.nextLong();
				System.out.println("Enter amount to transfer");
				amount = sc.nextInt();

				try {
					ubal = service.transferfund(accountNo, accountNo1, amount);
					System.out.println("Amount transferred Successfully");
					System.out.println("Updated balance for Account " + accountNo + " : " + ubal[0]);
					System.out.println("Updated balance for Account " + accountNo1 + " : " + ubal[1]);

				} catch (AccountNotFoundException|LowBalanceException|ClassNotFoundException|SQLException e) {
					System.out.println(e);
					break;
				} 
				break;

			// to show transactions
			case 6:

				System.out.println("Enter account number");
				accountNo = sc.nextLong();
				try{
					BankingTransaction trans = service.getTransactions(accountNo);
					System.out.println("--------Transactions----------");
					System.out.println("Transaction type : " + trans.getType());
					System.out.println("Transaction Id : " + trans.getTransaction_id());
					System.out.println("Transaction Account : " + trans.getAccNo());
					System.out.println("Transaction Amount : " + trans.getAmount());
				}
				catch(AccountNotFoundException|ClassNotFoundException|SQLException e){
					System.out.println(e);
					break;
				}
				break;
				
			// to exit
			case 7:
				System.err
				.println("\n\t\t\t\t\t\t\t  ***Exit Successful***\n\t\t\t\t\t\t\t***Thanks for visiting***");
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				break;

			}
		}

	}
}
