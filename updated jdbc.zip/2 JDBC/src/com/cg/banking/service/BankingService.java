package com.cg.banking.service;

import java.sql.SQLException;

import com.cg.banking.bean.BankingTransaction;
import com.cg.banking.exception.*;

public interface BankingService {

	public void createAccount(String name, String address, long accountNo, String phone, int balance)
			throws AccountAlreadyExistException, ClassNotFoundException, SQLException;

	public int showBalance(long accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException;

	public int deposit(long accountNo, int depositAmount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException;

	public int withdraw(long accountNo, int withdrawAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException;

	public int[] transferfund(long sendersAccountNo, long recieversAccountNo, int transferAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException;

	public BankingTransaction getTransactions(long accountNo) throws AccountNotFoundException,ClassNotFoundException, SQLException;

}
