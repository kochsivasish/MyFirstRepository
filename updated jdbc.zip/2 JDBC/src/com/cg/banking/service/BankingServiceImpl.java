package com.cg.banking.service;

import java.sql.SQLException;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransaction;
import com.cg.banking.dao.BankingDaoImpl;
import com.cg.banking.dao.BankingDao;
import com.cg.banking.exception.*;

public class BankingServiceImpl implements BankingService {

	BankingDao dao = new BankingDaoImpl();
	BankingTransaction trans = new BankingTransaction();

	boolean res;

	// to get the details if account exists or not and add account

	public void createAccount(String name, String address, long accountNo, String phone, int balance)
			throws AccountAlreadyExistException, ClassNotFoundException, SQLException {

		BankingBean tempAccount = dao.getAccountDetails(accountNo);
		BankingBean account = new BankingBean();

		if (tempAccount == null) {
			account.setAccountNo(accountNo);
			account.setAddress(address);
			account.setBalance(balance);
			account.setName(name);
			account.setPhoneNo(phone);
			dao.InsertData(account);
			
			trans.setAccNo(accountNo);
			trans.setType("Create");
			trans.setAmount(balance);
			trans.setTransaction_id((int) (Math.random() * 1000) + 10000);
			dao.setTransactions(trans);
		}
		else
		{
			throw new AccountAlreadyExistException();
		}

	}

	// to show balance

	public int showBalance(long accountNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		BankingBean account = dao.getAccountDetails(accountNo);
		if(account == null)
			throw new AccountNotFoundException();
		else {
			return account.getBalance();
		}
	}

	// to deposit

	public int deposit(long accountNo, int depositAmount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException {
		
		BankingBean account = dao.getAccountDetails(accountNo);
		int balance = 0;
		if(account == null)
			throw new AccountNotFoundException();
		else {
			balance = account.getBalance() + depositAmount;
			account.setBalance(balance);
			dao.updateData(account);
			
			trans.setAccNo(accountNo);
			trans.setType("Deposit");
			trans.setAmount(depositAmount);
			trans.setTransaction_id((int) (Math.random() * 1000) + 10000);
			dao.setTransactions(trans);
		}
	
		return balance;
	}

	// to withdraw

	public int withdraw(long accountNo, int withdrawAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		BankingBean account = dao.getAccountDetails(accountNo);
		int balance = 0;
		if(account == null)
			throw new AccountNotFoundException();
		else if(account.getBalance() < withdrawAmount){
			throw new LowBalanceException();
		}
		else{
			balance = account.getBalance() - withdrawAmount;
			account.setBalance(balance);
			dao.updateData(account);
			
			trans.setAccNo(accountNo);
			trans.setType("Withdraw");
			trans.setAmount(withdrawAmount);
			trans.setTransaction_id((int) (Math.random() * 1000) + 10000);
			dao.setTransactions(trans);
		}
		return balance;
	}

	// to transfer fund

	public int[] transferfund(long sendersAccountNo, long recieversAccNo, int transferAmount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		BankingBean account = dao.getAccountDetails(sendersAccountNo);
		BankingBean account1 = dao.getAccountDetails(recieversAccNo);
		int balance[] = new int[2];
		if(account == null || account1==null)
			throw new AccountNotFoundException();
		else if(account.getBalance() < transferAmount){
			throw new LowBalanceException();
		}
		else{
			balance[0] = account.getBalance() - transferAmount;
			balance[1] = account1.getBalance() + transferAmount;
			account.setBalance(balance[0]);
			account1.setBalance(balance[1]);
			dao.updateData(account);
			dao.updateData(account1);
			
			trans.setAccNo(sendersAccountNo);
			trans.setType("TransferDebit");
			trans.setAmount(transferAmount);
			trans.setTransaction_id((int) (Math.random() * 1000) + 10000);
			dao.setTransactions(trans);
			trans.setAccNo(recieversAccNo);
			trans.setType("TransferDebit");
			trans.setAmount(transferAmount);
			trans.setTransaction_id((int) (Math.random() * 1000) + 10000);
			dao.setTransactions(trans);
		}
		return balance;
	}

	@Override
	public BankingTransaction getTransactions(long accountNo) throws AccountNotFoundException,ClassNotFoundException, SQLException {
		
		trans = dao.getTransactions(accountNo);
		if(trans == null)
			throw new AccountNotFoundException();
		else
			return trans;
	}
}
