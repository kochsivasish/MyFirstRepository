package com.cg.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransaction;

public class BankingDaoImpl implements BankingDao {

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	BankingBean bank = new BankingBean();

	@Override
	public void InsertData(BankingBean account) throws ClassNotFoundException, SQLException {

		con = BankingDBConnector.getConnection();
		ps = con.prepareStatement("Insert into bank values (?,?,?,?,?)");

		ps.setString(1, account.getName());
		ps.setLong(2, account.getAccountNo());
		ps.setString(3, account.getAddress());
		ps.setString(4, account.getPhoneNo());
		ps.setInt(5, account.getBalance());

		int r = ps.executeUpdate();

		if (r == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	@Override
	public void updateData(BankingBean account) throws ClassNotFoundException, SQLException {

		con = BankingDBConnector.getConnection();
		ps = con.prepareStatement("Update bank set balance = ? where accountno = ?");
		ps.setInt(1, account.getBalance());
		ps.setLong(2, account.getAccountNo());

		int r = ps.executeUpdate();

		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankingBean getAccountDetails(long accountNo) throws ClassNotFoundException, SQLException {

		String query = "Select * from bank where accountno = ?";
		con = BankingDBConnector.getConnection();
		ps = con.prepareStatement(query);
		ps.setLong(1, accountNo);
		rs = ps.executeQuery();

		if (rs.next()) {
			bank.setName(rs.getString(1));
			bank.setAccountNo(rs.getLong(2));
			bank.setAddress(rs.getString(3));
			bank.setPhoneNo(rs.getString(4));
			bank.setBalance(rs.getInt(5));
		} else {
			bank = null;
		}
		return bank;
	}

	@Override
	public void setTransactions(BankingTransaction trans) throws ClassNotFoundException, SQLException {

		String query = "Insert into transactions values (?,?,?,?)";
		con = BankingDBConnector.getConnection();
		ps = con.prepareStatement(query);
		ps.setString(1, trans.getType());
		ps.setLong(2, trans.getAccNo());
		ps.setInt(3, trans.getAmount());
		ps.setInt(4, trans.getTransaction_id());

		int res = ps.executeUpdate();

		if (res == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}

	}

	@Override
	public BankingTransaction getTransactions(long accountNo) throws ClassNotFoundException, SQLException {

		BankingTransaction trans = new BankingTransaction();
		String query = "Select * from transactions where accountno = ?";
		con = BankingDBConnector.getConnection();
		ps = con.prepareStatement(query);
		ps.setLong(1, accountNo);

		rs = ps.executeQuery();

		if (rs.next()) {
			trans.setType(rs.getString(1));
			trans.setAccNo(rs.getLong(2));
			trans.setAmount(rs.getInt(3));
			trans.setTransaction_id(rs.getInt(4));
		}
		return trans;
	}

}
