package com.cg.banking.dao;

import java.sql.SQLException;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransaction;

public interface BankingDao {



	public void InsertData(BankingBean account) throws ClassNotFoundException, SQLException;
	
	public void updateData(BankingBean account) throws ClassNotFoundException, SQLException;
	
	public BankingBean getAccountDetails(long accountNo) throws ClassNotFoundException, SQLException;

	public void setTransactions(BankingTransaction trans) throws ClassNotFoundException, SQLException;

	public BankingTransaction getTransactions(long accountNo) throws ClassNotFoundException, SQLException;

}
